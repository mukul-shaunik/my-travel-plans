﻿var myapp = angular.module("myapp", ["firebase", "ngDialog"]);
myapp.controller("MyController", function ($scope, $firebase, $filter) {
    $scope.droneData = $firebase(new Firebase('https://cordovaapp-150305.firebaseio.com/DroneCoordinates'));
    $scope.droneData.$on('value', function () {
        $scope.drones = [];
        var drns = $scope.droneData.$getIndex();
        for (var i = 0; i < drns.length; i++) {
            $scope.drones.push({
                DelieveryId: $scope.droneData[drns[i]].DelieveryId,
                DroneId: $scope.droneData[drns[i]].DroneId,
                Latitude: $scope.droneData[drns[i]].Latitude,
                Longitude: $scope.droneData[drns[i]].Longitude,
                Time: $scope.droneData[drns[i]].Time
            });
        };
    });

    $scope.droneInfo = $firebase(new Firebase('https://cordovaapp-150305.firebaseio.com/DroneInfo'));
    $scope.dronesInfo = [];
    $scope.droneInfo.$on('value', function () {
        $scope.dronesInfo = [];
        var drns = $scope.droneInfo.$getIndex();
        for (var i = 0; i < drns.length; i++) {
            $scope.dronesInfo.push({
                DroneId: $scope.droneInfo[drns[i]].DroneId,
                DroneName: $scope.droneInfo[drns[i]].DroneName,
                DroneMfgDate: $scope.droneInfo[drns[i]].DronemfDt,
                DistCovered: $scope.droneInfo[drns[i]].DistCovered,
                BatStatus: $scope.droneInfo[drns[i]].BatStatus,
                NoofDelivery: $scope.droneInfo[drns[i]].NoofDelivery,
                PurchaseDate: $scope.droneInfo[drns[i]].PurchaseDate,
                LastMaintDate: $scope.droneInfo[drns[i]].LastMaintDate,
                NextMainDate: $scope.droneInfo[drns[i]].NextMainDate,
                DroneStatus: $scope.droneInfo[drns[i]].DroneStatus,
                DroneSource: $scope.GetDroneSource($scope.droneInfo[drns[i]].DroneId),
                DroneDest: $scope.GetDroneDestination($scope.droneInfo[drns[i]].DroneId),
                DroneTranId:$scope.GetDroneTransId($scope.droneInfo[drns[i]].DroneId)
            });
        };
    });

    $scope.GetDroneName = function (did) {

        var m = $scope.droneInfo.$getIndex();
        for (var i = 0; i < m.length; i++) {
            if ($scope.droneInfo[m[i]].DroneId == did ) {
                //alert($scope.drone[m[i]].DroneName);
                return $scope.droneInfo[m[i]].DroneName;
            }
        }
    };

    $scope.GetDroneSource = function (did) {

        var m = $scope.droneAssigmts.$getIndex();
        for (var i = 0; i < m.length; i++) {
            if ($scope.droneAssigmts[m[i]].DroneId == did && $scope.droneAssigmts[m[i]].DeliveryStatus == "Assigned") {
                //alert($scope.drone[m[i]].DroneName);
                return $scope.droneAssigmts[m[i]].SenAdd;
            }
        }
    };
    $scope.GetDroneDestination = function (did) {

        var m = $scope.droneAssigmts.$getIndex();
        for (var i = 0; i < m.length; i++) {
            if ($scope.droneAssigmts[m[i]].DroneId == did && $scope.droneAssigmts[m[i]].DeliveryStatus == "Assigned") {
                //alert($scope.drone[m[i]].DroneName);
                return $scope.droneAssigmts[m[i]].RecAdd;
            }
        }
    };

    $scope.GetDroneTransId = function (did) {

        var m = $scope.droneAssigmts.$getIndex();
        for (var i = 0; i < m.length; i++) {
            if ($scope.droneAssigmts[m[i]].DroneId == did && $scope.droneAssigmts[m[i]].DeliveryStatus == "Assigned") {
                //alert($scope.drone[m[i]].DroneName);
                return $scope.droneAssigmts[m[i]].DelId;
            }
        }
    };
    $scope.droneAssigmts = $firebase(new Firebase('https://cordovaapp-150305.firebaseio.com/DroneAssignment'));
    $scope.dronesAssigmt = [];
    $scope.droneAssigmts.$on('value', function () {
        $scope.dronesAssigmt = [];
        var drns = $scope.droneAssigmts.$getIndex();
        for (var i = 0; i < drns.length; i++) {
            $scope.dronesAssigmt.push({
                DelId: $scope.droneAssigmts[drns[i]].DelId,
                DroneId: $scope.droneAssigmts[drns[i]].DroneId,
                DroneName: $scope.GetDroneName($scope.droneAssigmts[drns[i]].DroneId),
                DeliveryTime: $scope.droneAssigmts[drns[i]].DeliveryTime,
                DeliveryStartTime: $scope.droneAssigmts[drns[i]].DeliveryStartTime,
                DeliveryExpTime: $scope.droneAssigmts[drns[i]].DeliveryExpTime,
                DeliveryStatus: $scope.droneAssigmts[drns[i]].DeliveryStatus,
                SenName: $scope.droneAssigmts[drns[i]].SenName,
                RecordId: $scope.droneAssigmts[drns[i]].RecordId,
                RecName: $scope.droneAssigmts[drns[i]].RecName,
                SenAdd: $scope.droneAssigmts[drns[i]].SenAdd,
                RecAdd: $scope.droneAssigmts[drns[i]].RecAdd,
                RecLatitude: $scope.droneAssigmts[drns[i]].RecLatitude,
                RecLongitude: $scope.droneAssigmts[drns[i]].RecLongitude,
                VaultName: $scope.droneAssigmts[drns[i]].VaultName,
                DroneOperator:$scope.droneAssigmts[drns[i]].DroneOperator
            });
        };
    });

    //LogData
    
    $scope.droneLogdata = $firebase(new Firebase('https://cordovaapp-150305.firebaseio.com/Logs'));
    $scope.loginfo = [];
    $scope.droneLogdata.$on('value', function () {
        $scope.loginfo = [];
        var drns = $scope.droneLogdata.$getIndex();
        for (var i = 0; i < drns.length; i++) {
            $scope.loginfo.push({
                TransId: $scope.droneLogdata[drns[i]].TrasId,
                DroneId: $scope.droneLogdata[drns[i]].DroneId,
                Logtext: $scope.droneLogdata[drns[i]].LogText,
                DroneName: $scope.GetDroneName($scope.droneLogdata[drns[i]].DroneId),
                TimeStamp: $scope.droneLogdata[drns[i]].TimeStamp
            });
        };
    });

    $scope.Addrow=function()
    {
       
        var today = new Date();
        var item = {
            DelId: "#65789",
            DroneId: "2",
            DeliveryTime: $filter('date')(new Date(), "dd-MMM-yyyy"),
            //DeliveryStartTime: today.getHours()+":00",
            //DeliveryExpTime: today.getHours() + 2+":00",
            DeliveryStartTime:"09:30",
            DeliveryExpTime:"12:30",
            DeliveryStatus: "Assigned",
            SenName: "Aish",
            RecName: "Rana",
            RecLattitude: "40.76047913656953",
            RecLongitude: "-73.97684737174018",
            CurrentPosition: "1",
            RecordId: $scope.droneAssigmts.$getIndex().length+1,
            DeliveryAmount: "$10000",
            Feedback: "",
            RecAdd: "SOL",
            ReceiverAckn: "D",
            SenAdd: "WTC",
            VaultName:"WUD243A"
        }
        $scope.droneAssigmts.$add(item);
    }
    $scope.showcard = function (index) {
        if (index == 1) {
            document.getElementById("Showcard2").setAttribute("style", "display:none");
            document.getElementById("Showcard3").setAttribute("style", "display:none");
            if (document.getElementById("Showcard" + index).style.display == "none") {
                document.getElementById("Showcard" + index).style.display = "block";
                document.getElementById("Showcard" + index).style.display = "";

            }
            //else {

            //    document.getElementById("Showcard" + index).setAttribute("style", "display:none");

            //}
        }
        if (index == 2) {
            document.getElementById("Showcard1").setAttribute("style", "display:none");
            document.getElementById("Showcard3").setAttribute("style", "display:none");
            if (document.getElementById("Showcard" + index).style.display == "none") {
                document.getElementById("Showcard" + index).style.display = "block";
                document.getElementById("Showcard" + index).style.display = "";

            }
            //else {

            //    document.getElementById("Showcard" + index).setAttribute("style", "display:none");

            //}
        }
        if (index == 3) {
            document.getElementById("Showcard2").setAttribute("style", "display:none");
            document.getElementById("Showcard1").setAttribute("style", "display:none");
            if (document.getElementById("Showcard" + index).style.display == "none") {
                document.getElementById("Showcard" + index).style.display = "block";
                document.getElementById("Showcard" + index).style.display = "";

            }
            //else {

            //    document.getElementById("Showcard" + index).setAttribute("style", "display:none");

            //}
        }


    }
    $scope.showtd = function (index) {
        //$scope.dronesAssigmts = [];
        
        if (document.getElementById("Compl" + index).style.display == "none") {
            document.getElementById("Compl" + index).style.display = "block";
            document.getElementById("Compl" + index).style.display = "";

        }
        else {

            document.getElementById("Compl" + index).setAttribute("style", "display:none");

        }
        //$scope.dronesAssigmt.push({
        //    'SenName': dronesAssigmt.SenName,
        //    'RecName': dronesAssigmt.RecName,
        //    'RecAdd': dronesAssigmt.RecAdd,
        //});
    }
    $scope.today = $filter('date')(new Date(), "dd-MM-yyyy");
   // $scope.today = new Date();
    //var tick = function () {
    //    $scope.clock = Date.now();
    //}
    //tick();
    //$interval(tick, 1000);
    $scope.droneLog = $firebase(new Firebase('https://cordovaapp-150305.firebaseio.com/Logs'));
    $scope.AddLog = function (droneid, text) {
        var date = new Date();
        $scope.droneLog.$add({
            DroneId: droneid,
            LogText: text,
            TransId: $scope.GetDroneTransId(droneid),
            TimeStamp:$filter('date')(new Date(), 'HH:mm:ss dd-MMM-yyyy')
        });
    }
    function buildEndPoint(key, $firebase) {
        return $firebase(new Firebase('https://cordovaapp-150305.firebaseio.com/DroneCoordinates/' + key));
    }
    function buildEndPoint(key, $firebase) {
        return $firebase(new Firebase('https://cordovaapp-150305.firebaseio.com/DroneAssignment/' + key));
    }
    function buildEndPoint(key, $firebase) {
        return $firebase(new Firebase('https://cordovaapp-150305.firebaseio.com/DroneAssignment/' + key));
    }
    var line;
    var marker;
    var lineCoordinates;
    var map;
    $scope.Drone_Click = function (id) {
        if (id == 4) {
            var mapOptions = {
                center: new google.maps.LatLng(40.7118650225794, -74.01306283068845),
                zoom: 15,
                mapTypeId: google.maps.MapTypeId.TERRAIN
            };

            map = new google.maps.Map(document.getElementById('map-canvas'),
            mapOptions);

            lineCoordinates = [
            new google.maps.LatLng(40.7118650225794, -74.01306283068845),
            new google.maps.LatLng(40.69051952455772, -74.04561411929319)];

            // Define the symbol, using one of the predefined paths ('CIRCLE')
            // supplied by the Google Maps JavaScript API.
            var lineSymbol = {
                path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW,
                scale: 5,
                strokeWeight: 2,
                strokeColor: '#393'
            };
            // Create the polyline and add the symbol to it via the 'icons' property.
            line = new google.maps.Polyline({
                path: lineCoordinates,
                icons: [{
                    icon: lineSymbol,
                    offset: '100%'
                }],
                map: map
            });
        }
        else if(id == 5) {
            var mapOptions = {
                center: new google.maps.LatLng(40.783465308899586, -73.96585600000003),
                zoom: 15,
                mapTypeId: google.maps.MapTypeId.TERRAIN
            };

            map = new google.maps.Map(document.getElementById('map-canvas'),
            mapOptions);

            lineCoordinates = [
            new google.maps.LatLng(40.783465308899586, -73.96585600000003),
            new google.maps.LatLng(40.70385815165002, -74.0165432319011)];

            // Define the symbol, using one of the predefined paths ('CIRCLE')
            // supplied by the Google Maps JavaScript API.
            var lineSymbol = {
                path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW,
                scale: 5,
                strokeWeight: 2,
                strokeColor: '#393'
            };
            // Create the polyline and add the symbol to it via the 'icons' property.
            line = new google.maps.Polyline({
                path: lineCoordinates,
                icons: [{
                    icon: lineSymbol,
                    offset: '100%'
                }],
                map: map
            });
        }

        animateCircle();
    }
    function animateCircle() {
        var infowindow = new google.maps.InfoWindow();
        var count = 0;
        window.setInterval(function () {
            count = (count + 1) % 200;
            var image = {
                url: '../images/droneG1.png', // url
                scaledSize: new google.maps.Size(40, 60), // scaled size
            };
            var icons = line.get('icons');
            icons[0].offset = (count / 2) + '%';
            line.set('icons', icons);
            var position = google.maps.geometry.spherical.interpolate(lineCoordinates[0], lineCoordinates[1], (count / 200));
            if (!marker) {
                marker = new google.maps.Marker({
                    position: position,
                    map: map,
                    icon: image,
                    size:40
                });
                infowindow.setContent(marker.getPosition().toUrlValue(6));
                infowindow.open(map, marker);
            } else {
                marker.setPosition(position);
            }
            infowindow.setContent(marker.getPosition().toUrlValue(6));
        }, 1000);
    }
});

function AddingLog(droneid, text) {
    angular.element(document.getElementById('mainController')).scope().AddLog(droneid, text)
}