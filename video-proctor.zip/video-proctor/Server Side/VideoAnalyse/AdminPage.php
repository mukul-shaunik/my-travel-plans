<?php
$emp=$_GET["EmpID"];
//LDAP Search
$adServer = "ldap://ad.infosys.com";
	
$ldap = ldap_connect($adServer);
$username = //Username;
$password = //PWD;

$ldaprdn = 'itlinfosys' . "\\" . $username;

ldap_set_option($ldap, LDAP_OPT_PROTOCOL_VERSION, 3);
ldap_set_option($ldap, LDAP_OPT_REFERRALS, 0);

$bind = @ldap_bind($ldap, $ldaprdn, $password);


if ($bind) {
	$filter="(company=$emp)";
	$result = ldap_search($ldap,"dc=ad,dc=infosys,dc=COM",$filter);
	ldap_sort($ldap,$result,"sn");
	$info = ldap_get_entries($ldap, $result);
	for ($i=0; $i<$info["count"]; $i++)
	{
		if($info['count'] > 1)
			break;
		$EmpName=$info[$i]["givenname"][0];
		$Emploc= $info[$i]["physicaldeliveryofficename"][0];
		//echo $EmpName; 
		//echo $Emploc;
	}
	@ldap_close($ldap);
} else {
	$msg = "Invalid email address / password";
	//echo $msg;
}

//End of LDAP
?>
<html>
<head>
<title>An ICETS Initiative</title>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/material-components-web.css" rel="stylesheet" type="text/css">
    <link href="css/demos.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500">
    <link href="https://fonts.googleapis.com/css?family=Roboto+Mono" rel="stylesheet">
<style>
 .bga {
            background-color: #ffde38 !important;
            color: black !important;
        }

        .bg {
            color: #ffde38 !important;
            background-color: black !important;
        }

        .mdc-toolbar {
            background-color: #21409A;
        }

        .mdc-theme--text-primary-on-primary {
            color: white !important;
        }

        .mdc-toolbar a, .mdc-toolbar a:visited {
            color: white;
        }

        .mdc-toolbar .mdc-tab-bar .mdc-tab--active, .mdc-toolbar .mdc-tab-bar .mdc-tab:hover {
            color: white !important;
        }
       
        .mdc-card__primary{
            padding:10px;
        }
        .mdc-card__primary:last-child{
            padding:0px 0px 10px 10px;
        }
        .demo-card {
            max-width: 21.875rem;
            /* 350sp */
            margin-bottom: 48px;
        }
        img{
            height:150px;width:auto;
        }
      

        @media(min-width: 768px) {
            .demo-card {
                margin-bottom: 10px;
            }
        }

        html {
            font-size: 75%;
            /*overflow: hidden;*/
            overflow: auto;
        }

       
        .mdc-card__title--large{
            color:#219CD7;
        }
        .mdc-card__subtitle{
            color:#47BAEB;
        }


          
            h1{
                font-weight: 900;
    color:#219CD7;
            }
        .mdc-ripple-surface:after {
            content: '\002B' !important;
            color: black;
        }

</style>
<script
  src="https://code.jquery.com/jquery-3.3.1.min.js"
  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous"></script>
  <script defer src="https://code.getmdl.io/1.3.0/material.min.js"></script>
  <script src="js/material-components-web.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.2.9/angular.min.js"></script>
	 <script>
        var drawerEl = document.querySelector('.mdc-temporary-drawer');
        var MDCTemporaryDrawer = mdc.drawer.MDCTemporaryDrawer;
        var drawer = new MDCTemporaryDrawer(drawerEl);
        document.querySelector('.demo-menu').addEventListener('click', function () {
            drawer.open = true;
        });
        drawerEl.addEventListener('MDCTemporaryDrawer:open', function () {
            console.log('Received MDCTemporaryDrawer:open');
        });
        drawerEl.addEventListener('MDCTemporaryDrawer:close', function () {
            console.log('Received MDCTemporaryDrawer:close');
        });
        (function (global) {
            [].forEach.call(document.querySelectorAll('.mdc-ripple-surface:not([data-demo-no-js])'), function (surface) {
                mdc.ripple.MDCRipple.attachTo(surface);
            });
        })(this);
        function openInfo(id) {
            var heroSelect = document.getElementById('js-select');
            mdc.select.MDCSelect.attachTo(heroSelect);

            var dialogScrollable = new mdc.dialog.MDCDialog(document.getElementById('aside' + id));
            dialogScrollable.show();

            var dynamicTabBar = window.dynamicTabBar = new mdc.tabs.MDCTabBar(document.querySelector('#dynamic-tab-bar' + id));
            var panels = document.getElementById('panels' + id);
            function updatePanel(index) {
                var activePanel = panels.querySelector('.panel.active');
                if (activePanel) {
                    activePanel.classList.remove('active');
                }
                var newActivePanel = panels.querySelector('.panel:nth-child(' + (index + 1) + ')');
                if (newActivePanel) {
                    newActivePanel.classList.add('active');
                }
            }

            dynamicTabBar.listen('MDCTabBar:change', function (t) {
                var dynamicTabBar = t.detail;
                var nthChildIndex = dynamicTabBar.activeTabIndex;

                updatePanel(nthChildIndex);
            });
        }
        (function () {
            var heroSelect = document.getElementById('js-select');
            mdc.select.MDCSelect.attachTo(heroSelect);
            var dialogScrollable = new mdc.dialog.MDCDialog(document.querySelector('.mdc-dialog-with-list'));
            var dialog = document.querySelectorAll('.dialog-with-list-activation')
            for (var i = 0; i < dialog.length; i++) {
                dialog[i].addEventListener('click', function (event) {
                    //  dialogScrollable.lastFocusedTarget = evt.target;
                    dialogScrollable.show();
                });
            }
            var dynamicTabBar = window.dynamicTabBar = new mdc.tabs.MDCTabBar(document.querySelector('#dynamic-tab-bar'));
            var panels = document.querySelector('.panels');
            function updatePanel(index) {
                var activePanel = panels.querySelector('.panel.active');
                if (activePanel) {
                    activePanel.classList.remove('active');
                }
                var newActivePanel = panels.querySelector('.panel:nth-child(' + (index + 1) + ')');
                if (newActivePanel) {
                    newActivePanel.classList.add('active');
                }
            }

            dynamicTabBar.listen('MDCTabBar:change', function (t) {
                var dynamicTabBar = t.detail;
                var nthChildIndex = dynamicTabBar.activeTabIndex;

                updatePanel(nthChildIndex);
            });

        })();

var acc = document.getElementsByClassName("accordion");
        var i;

        for (i = 0; i < acc.length; i++) {
            acc[i].addEventListener("click", function () {
                this.classList.toggle("active");
                var panel = this.nextElementSibling;
                if (panel.style.maxHeight) {
                    panel.style.maxHeight = null;
                } else {
                    panel.style.maxHeight = panel.scrollHeight + "px";
                }
            });
        }
    </script>
	
  <script type="text/javascript">
  var x;
  if(navigator.appName.search('Microsoft')>-1) { x = new ActiveXObject('MSXML2.XMLHTTP'); }
  else { x = new XMLHttpRequest(); }
 
  function showdata() {
    if(x.readyState==4) {
		//alert("Hi");
      var el = document.getElementById('VideoFrame'); 
	  el.innerHTML = x.responseText;
    }
  }
  function test(){
	var empid=<?php echo $emp?>;// document.getElementById("empid").value;
	//alert("it's started working");
	x.open('get', 'Admin.php?emp1='+empid, true); 
    x.onreadystatechange= showdata;
    x.send(null);
  }
  function myFunction() {
			    myVar = setInterval(alertFunc,200);
			//alert("it's started working");
			}

	function alertFunc() {
	    //take_snapshot();
		//getdata();
		showdata();
		//t_result();
		test();
		//alert("updated");
	} 
	//test();
	myFunction();
  //setInterval(test(),150);
  </script>
</head>
<body style="overflow-x:hidden">	
	 <form id="form1" runat="server">

        <div class="container-fluid" >
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12" style="padding: 0px">
                    <div class="mdc-toolbar tool">
                        <div class="mdc-toolbar__row" style="min-height: 20px; height: 37px;">
                            <div class="mdc-toolbar__section mdc-toolbar__section--shrink-to-fit mdc-toolbar__section--align-start" >

                                <a class="mdc-toolbar__title title" style="font-size:22px;">INFOSYS PROCTORING SYSTEM (IPS) </a>
                            </div>
                            <div class="mdc-toolbar__section my-modified-toolbar-section mdc-toolbar__section--align-end">
                                <a class="mdc-toolbar__title title"><span>Chandan Malu (ETA Admin)</span><i style="vertical-align: middle; margin-left: 5px" class="material-icons">perm_identity</i>&nbsp;&nbsp;</a>
                               
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
			<h1 class="mdc-typography--display1"><span><i style="vertical-align:middle; margin-left: 450px;" class="material-icons">person</i><?php echo $EmpName. ' (' .$emp. ', ' .$Emploc. ') '; ?></span></h1>
            <div class="row" style="margin-bottom:10px;height:730px">
			
                  <div id="VideoFrame"> 
					</div>
                    
                    </div>
               
<div class="row" style="bottom: 0px;">
                <footer>
                    <div class="mdc-toolbar tool">
                        <div class="mdc-toolbar__row" style="min-height: 20px; height: 40px;">
                            <div class="mdc-toolbar__section mdc-toolbar__section--shrink-to-fit mdc-toolbar__section--align-start">

                                <a class="mdc-toolbar__title title">Privacy Statement | Terms Of Use</a>
                            </div>
                            <div class="mdc-toolbar__section my-modified-toolbar-section mdc-toolbar__section--align-end">
                                <a class="mdc-toolbar__title title">Infosys Center for Emerging Technology Solutions (ICETS)&nbsp;&nbsp; </a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
		 </div>
    </form>

  
  

</body>
</html>

