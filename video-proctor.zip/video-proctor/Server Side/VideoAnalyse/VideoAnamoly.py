import cv2
import io
import os
import numpy as np
import shutil
from PIL import Image
import datetime
import atexit
import pyaudio
import wave
import threading
import time
import subprocess
import argparse
import sys
from flask import Flask,send_file
import matplotlib.pyplot as plt
from urllib.request import urlopen
ap = argparse.ArgumentParser()
ap.add_argument("-id", "--id", default=None,
				help="emp id")
args = vars(ap.parse_args())
faceImg = []
recordImg=[]
shank=[]
imgCount=1
timeCount=0
AnamolyType=''
PrevAnamolyType=''
EmpId=args["id"]
video=cv2.VideoCapture("C:\\xampp\\htdocs\\ws\\uploads\\"+EmpId+"-merged.webm")
PCount,FCount,NPCount,UCount,NVSCount=0,0,0,0,0
PTCount,FTCount,NPTCount,UTCount,NVSTCount=0,0,0,0,0
#url='http://10.219.34.23:8000/ws/images1/'
#atexit.register(closeWindow)
filename = ''
#def __init__(self):
	#self.video = cv2.VideoCapture(0)
fps = 3               # fps should be the minimum constant rate at which the camera can
fourcc = "MJPG"       # capture images (with no decrease in speed over time; testing is required)
frameSize = (640,480) # video formats and sizes also depend and vary according to the camera used
summary_video_filename ="C:\\xampp\\htdocs\\ws\\VideoAnalyse\\Summary\\"+EmpId+"_video.avi"
summary_video_writer = cv2.VideoWriter_fourcc(*fourcc)
video_out = cv2.VideoWriter(summary_video_filename, summary_video_writer,fps, frameSize)
frame_counts = 1
start_time = time.time()
full_video_filename ="C:\\xampp\\htdocs\\ws\\VideoAnalyse\\Processed\\"+EmpId+"__video.avi"
full_video_writer = cv2.VideoWriter_fourcc(*fourcc)
video_out1 = cv2.VideoWriter(full_video_filename, full_video_writer,fps, frameSize)
while True:
	path="C:\\xampp\\htdocs\\ws\\VideoAnalyse\\images\\"+EmpId+"\\"
	os.makedirs(path, exist_ok=True)
	if(imgCount==1):
		then = time.time()
		print(then)
		EmpId=EmpId
		file = open("C:\\xampp\\htdocs\\ws\\VideoAnalyse\\ExamineeList.txt", "a")
		file.write(','+EmpId) 
		file.close()
		#url=url+'pic__'+EmpId+'.jpeg'
		filesToRemove = [os.path.join(path,f) for f in os.listdir(path)]
		for f in filesToRemove:
			os.remove(f)
	detector=cv2.CascadeClassifier('C:\\xampp\\htdocs\\ws\\VideoAnalyse\\haarcascade_frontalface_alt.xml')
	#imgResp=urlopen(url)
	_,img=video.read()
	#imgNp=np.array(bytearray(imgResp.read()),dtype=np.uint8)
	#img=cv2.imdecode(imgNp,-1)
	recordImg=img
	#cv2.imshow("label",img)
	#cv2.waitKey()
	gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
	faces = detector.detectMultiScale(gray, 1.3, 5)
	cv2.putText(img,datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') ,(450,460),cv2.FONT_HERSHEY_PLAIN, 1, (0,0,255),2) 
	for (x,y,w,h) in faces:
		cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
		faceImg=gray[y:y+h,x:x+w]
	#ret, jpeg = cv2.imencode('.jpg', img)
	if imgCount>10 and imgCount<40:
		pil_im = Image.fromarray(faceImg)
		name=path+EmpId+"_"+str(imgCount)+".jpg"
		imgCount=imgCount+1
		pil_im.save(name)
	else:
		imgCount=imgCount+1
	now = time.time()
	if(imgCount==40):
		recognizer = cv2.face.LBPHFaceRecognizer_create()
		detector= cv2.CascadeClassifier("C:\\xampp\\htdocs\\ws\\VideoAnalyse\\haarcascade_frontalface_alt.xml");
		#get the path of all the files in the folder
		imagePaths=[os.path.join(path,f) for f in os.listdir(path)] 
		#create empth face list
		faceSamples=[]
		#create empty ID list
		Ids=[]
		#now looping through all the image paths and loading the Ids and the images
		for imagePath in imagePaths:
			#loading the image and converting it to gray scale
			pilImage=Image.open(imagePath).convert('L')
			#Now we are converting the PIL image into numpy array
			imageNp=np.array(pilImage,'uint8')
			#getting the Id from the image
			Id=int(os.path.split(imagePath)[-1].split("_")[0])
		
			# extract the face from the training image sample
			faces=detector.detectMultiScale(imageNp)
			#If a face is there then append that in the list as well as Id of it
			for (x,y,w,h) in faces:
				faceSamples.append(imageNp[y:y+h,x:x+w])
				Ids.append(Id)
		recognizer.train(faceSamples, np.array(Ids))
		recognizer.save(path+EmpId+'.yml')
	if(os.path.isfile(path+EmpId+'.yml')):
		
		face_cascade = cv2.CascadeClassifier('C:\\xampp\\htdocs\\ws\\VideoAnalyse\\haarcascade_frontalface_alt.xml')
		eye_cascade = cv2.CascadeClassifier('C:\\xampp\\htdocs\\ws\\VideoAnalyse\\haarcascade_eye.xml')
		rec = cv2.face.LBPHFaceRecognizer_create()
		rec.read(path+EmpId+'.yml')
		id=0
		font=cv2.FONT_HERSHEY_SIMPLEX
		body_cascade=cv2.CascadeClassifier('C:\\xampp\\htdocs\\ws\\VideoAnalyse\\HS.xml')
		bodies=body_cascade.detectMultiScale(gray, 1.3, 4)
		pupilDetected = eye_cascade.detectMultiScale(gray, 1.3, 5)
		print("faces"+str(len(faces)))
		for (x,y,w,h) in pupilDetected:
				cv2.rectangle(img, (x,y), ((x+w),(y+h)), (0,0,255),1)
				cv2.line(img, (x,y), ((x+w,y+h)), (0,0,255),1)
				cv2.line(img, (x+w,y), ((x,y+h)), (0,0,255),1)
				cv2.circle(img,(int(x+(w/2)),int(y+(h/2))),5,255,-1)
		for (x,y,w,h) in bodies:
			cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),2) 
		if(len(faces)>1):
			print("true in FT");
			cv2.putText(img,"More than one face detected",(350,30),cv2.FONT_HERSHEY_PLAIN, 1, (0,0,255),2)
			logtext_file = open("C:\\xampp\\htdocs\\ws\\VideoAnalyse\\Log_"+EmpId+".txt", "a")
			logtext_file.write('\n' +'Time: %s '%str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+ ' No of faces detected: %s' %len(faces))
			logtext_file.close()
			AnamolyType="MFD"
			FTCount=FTCount+1
			video_out.write(img)
			#if(FTCount==1):
			#	FCount=1;
		elif(len(bodies)==1 and len(faces)==0):
			print("true in NVS");
			cv2.putText(img,"Person detected but not viewing the screen" ,(250,30),cv2.FONT_HERSHEY_PLAIN, 1, (0,0,255),2)
			logtext_file = open("C:\\xampp\\htdocs\\ws\\VideoAnalyse\\Log_"+EmpId+".txt", "a")
			logtext_file.write('\n' +'Time: %s '%str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+ ' Person detected but not viewing the screen')
			logtext_file.close()
			AnamolyType="PDNV"
			NVSTCount=NVSTCount+1
			video_out.write(img)
			#if(NVSTCount==1):
			#	NVSCount=1
		elif(len(bodies)>1):
			print("true in PT");
			cv2.putText(img,"More than one person detected" ,(350,30),cv2.FONT_HERSHEY_PLAIN, 1, (0,0,255),2) 
			logtext_file = open("C:\\xampp\\htdocs\\ws\\VideoAnalyse\\Log_"+EmpId+".txt", "a")
			logtext_file.write('\n' +'Time: %s '%str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+ ' More than one person detected')
			logtext_file.close()
			AnamolyType="MPD"
			PTCount=PTCount+1
			video_out.write(img)
			#if(PTCount==1):
			#	PCount=1
		elif(len(bodies)==0 and len(faces)==0 and len(pupilDetected)==0):
			print("true in NPT");
			cv2.putText(img,"No person detected" ,(250,30),cv2.FONT_HERSHEY_PLAIN, 1, (0,0,255),2)
			logtext_file = open("C:\\xampp\\htdocs\\ws\\VideoAnalyse\\Log_"+EmpId+".txt", "a")
			logtext_file.write('\n' +'Time: %s '%str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+ ' No person detected')
			logtext_file.close()
			AnamolyType="NPD"
			NPTCount=NPTCount+1
			video_out.write(img)
			#if(NPTCount==1):
			#	NPCount=1
		for (x,y,w,h) in faces:
			cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
			id,conf=rec.predict(gray[y:y+h,x:x+w])
			#print(conf)
			if(conf>70):
				id="Unknown"
				if(len(faces)==1):
					cv2.putText(img,"Unknown person detected" ,(350,30),cv2.FONT_HERSHEY_PLAIN, 1, (0,0,255),2) 
					logtext_file = open("C:\\xampp\\htdocs\\ws\\VideoAnalyse\\Log_"+EmpId+".txt", "a")
					logtext_file.write('\n' +'Time: %s '%str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))+ ' Unknown person detected')
					logtext_file.close()
					AnamolyType="UPD"
					UTCount=UTCount+1
					video_out.write(img)
					#if(UTCount==1):
					#	UCount=1
			cv2.putText(img,str(id),(x,y+h),font,0.55,(0,255,0),1)
		
	if((now-then)<300):
		print("Video Writing" +str(now-then))
		#video_out.write(img)
		video_out1.write(img)
		#time.sleep(0.16)
		#frame_counts += 1
	else:
		#print("Video releases")
		video_out.release()
		video_out1.release()
		#sys.exit("End Programme")
		#video_out= None;
		break
	#cv2.waitKey(0)
video_out.release()
video_out1.release()
cv2.destroyAllWindows()