<?php
//echo("hello world");
//system("cmd /c C:\xampp\htdocs\shank\shank.bat");
ini_set('max_execution_time', 100);
$emp=$_GET["emp1"];
system('cmd.exe /c C:\xampp\htdocs\ws\VideoAnalyse\ProctoringSystemAnamoly.bat '.$emp.'');
//exec("start cmd C:\xampp\htdocs\shank\shank.bat");

?>