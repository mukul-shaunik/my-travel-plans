<?php
$emp=$_GET["emp1"];

if ((file_exists('C:\\xampp\\htdocs\\ws\\images\\pic_'.$emp.'.jpeg')) ) {
$image = 'C:\\xampp\\htdocs\\ws\\images\\pic_'.$emp.'.jpeg';

}
else
{
$image = 'C:\\xampp\\htdocs\\ws\\VideoAnalyse\\staticImage.jpg';

}
if((file_exists('C:\\xampp\\htdocs\\ws\\VideoAnalyse\\'.$emp.'.jpg')))
{
	$chart = 'C:\\xampp\\htdocs\\ws\\VideoAnalyse\\'.$emp.'.jpg';
}
else{
	$chart = 'C:\\xampp\\htdocs\\ws\\VideoAnalyse\\staticGraph.png';
}
$imageData = base64_encode(file_get_contents($image));
$chartData = base64_encode(file_get_contents($chart));
$src = 'data: '.mime_content_type($image).';base64,'.$imageData;
$chartsrc = 'data: '.mime_content_type($chart).';base64,'.$chartData;
 echo '<div class="col-lg-12">
                    <div class="col-lg-10">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="col-lg-7">
                                    <h1 class="mdc-typography--display1"><span ><i style="vertical-align:middle" class="material-icons">videocam</i></span>Candidate</h1>
                                    <div >
                                   <img style="width:600px;height:480px;" src="' . $src . '" />
                                     </div>
                                </div>
                                <div class="col-lg-5" >
                                 <h1 class="mdc-typography--display1"><span ><i style="vertical-align:middle" class="material-icons">bar_chart</i></span>Indicators</h1>
                                  <div style="border:1px dashed darkblue">
										<img id=chartimg style="width:410px;height:480px;" src="' . $chartsrc . '">
                                  </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="col-lg-7">
                                    <h1 class="mdc-typography--display1"><span><i style="vertical-align:middle;" class="material-icons">short_text</i></span>Examination Events</h1>
									<div style="height:100px;width:auto;overflow:auto"> ';
                                
//Log Display
if ((file_exists('C:\xampp\\htdocs\\ws\\VideoAnalyse\\Log_'.$emp.'.txt')) ) {
$contents = array_reverse(file("Log_".$emp.".txt"));
foreach($contents as $line) {
	echo '<li> '.$line.'</li>';	
}	
}
echo '</div></div>
                                <div class="col-lg-5" >
								<h1 class="mdc-typography--display1"><span ><i style="vertical-align:middle" class="material-icons">bar_chart</i></span>Legend</h1>
                                    
									<div style="border:1px dashed darkblue">
									<label>&nbsp;&nbsp;MFD - More than One Face Detected</label><br />
									<label>&nbsp;&nbsp;PNV - Person detected but Not Viewing screen</label><br />
									<label>&nbsp;&nbsp;MPD - More than one Person Detected</label><br />
									<label>&nbsp;&nbsp;NPD - No Person Detected</label><br />
									<label>&nbsp;&nbsp;UPD - Unknown Person Detected</label><br />
									</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2" style="height:560px;overflow-y:auto">
                        <h1 class="mdc-typography--display1" style="margin-left:-15px"><span><i style="vertical-align:middle;" class="material-icons">group</i></span>Examinees</h1>
						';

//Right Side Employee panel
$contents = file("ExamineeList.txt");
$emplist = explode(",", $contents[0]);
$empCount=0;
foreach($emplist as $line) {
$empCount=$empCount+1;
if ((file_exists('C:\\xampp\\htdocs\\ws\\images\\pic_'.$line.'.jpeg')) ) {
$image1 = 'C:\\xampp\\htdocs\\ws\\images\\pic_'.$line.'.jpeg';
//$chart = 'C:\\xampp\\htdocs\\ws\\VideoAnalyse\\'.$line.'.jpg';
}
else
{
$image1 = 'C:\\xampp\\htdocs\\ws\\VideoAnalyse\\staticImage.jpg';
//$chart = 'C:\\xampp\\htdocs\\ws\\VideoAnalyse\\staticGraph.png';
}
#echo $image;
// Read image path, convert to base64 encoding
$imageData1 = base64_encode(file_get_contents($image1));
//$chartData = base64_encode(file_get_contents($chart));
// Format the image SRC:  data:{mime};base64,{data};
$src1 = 'data: '.mime_content_type($image).';base64,'.$imageData1;
//$chartsrc = 'data: '.mime_content_type($chart).';base64,'.$chartData;
echo  '<div class="row" style="margin-right:2px">
                            
                                <div class="mdc-card demo-card"><section class="mdc-card__media demo-card__16-9-media" style="padding:0px">
                                     <a href="AdminPage.php?EmpID='.$line.'" > 
									  <img   src="' . $src1 . '" style="height:150px;width:auto" /></a>
                                    </section>
                                    <section class="mdc-card__primary" style="background-color:rgba(0, 0, 0, .06)">
                                        <h1 class="mdc-card__title mdc-card__title--large">Examinee #'.$empCount.'</h1>
                                        <h2 class="mdc-card__subtitle">'.$line.'</h2>
                                    </section></div></div>';
}
echo '</div></div></div>';
//echo file_get_contents(  );

//echo '<img id=img2 src="' . $src . '">';



?>
