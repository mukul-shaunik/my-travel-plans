<?php 
header('Access-Control-Allow-Origin: *'); 
// baseFromJavascript will be the javascript base64 string retrieved of some way (async or post submited)
$baseFromJavascript = $_POST['base64']; //your data in base64 'data:image/png....';
// We need to remove the "data:image/png;base64,"
$base_to_php = explode(',', $baseFromJavascript);
// the 2nd item in the base_to_php array contains the content of the image
$data = base64_decode($base_to_php[1]);
//EmpID
$emp=$_GET["EmpID"];
// here you can detect if type is png or jpg if you want
$filepath = "images/pic_".$emp.".jpeg"; // or image.jpg
$filepathforanalyse = "imagesAdmin/pic__".$emp.".jpeg"; 

// Save the image in a defined path
file_put_contents($filepath,$data);
file_put_contents($filepathforanalyse,$data);
?>

